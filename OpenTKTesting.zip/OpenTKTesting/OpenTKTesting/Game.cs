﻿using System;

using OpenTK.Graphics.OpenGL4;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.Desktop;
using OpenTK.Windowing.GraphicsLibraryFramework;

using OpenTKTesting.Graphics.Shapes;

namespace OpenTKTesting
{
    public class Game : GameWindow
    {
        float[] a = { 200, 200 };
        float[] b = { 200, 400 };
        float[] c = { 400, 400 };

        private int VBO;
        private int VAO;

        Shader shader;

        Rectangle r1;
        Rectangle r2;

        public Game(int width, int height, string title)
            :base(GameWindowSettings.Default, NativeWindowSettings.Default)
        {
            Size = (width, height);
            Title = title;
        }

        protected override void OnLoad()
        {
            base.OnLoad();
            GL.ClearColor(0f, 0.7f, 0f, 1f);
            shader = new Shader("../../../Shaders/shader.vert", "../../../Shaders/shader.frag");


            r1 = new Rectangle(200, 200, 300, 300, 0);
            r2 = new Rectangle(300, 100, 250, 600, 1);
            shader.Use();
        }

        protected override void OnRenderFrame(FrameEventArgs e)
        {

            GL.Clear(ClearBufferMask.ColorBufferBit);

            //Code goes here.
            r1.Render();
            r2.Render();

            SwapBuffers();
            base.OnRenderFrame(e);
        }

        protected override void OnUpdateFrame(FrameEventArgs e)
        {
            base.OnUpdateFrame(e);

            KeyboardState input = KeyboardState;

            if (input.IsKeyPressed(Keys.Escape))
            {
                Close();
            }
        }

        protected override void OnResize(ResizeEventArgs e)
        {
            base.OnResize(e);
            GL.Viewport(0, 0, Size.X, Size.Y);
        }

        protected override void OnUnload()
        {
            base.OnUnload();

            // Unbind all the resources by binding the targets to 0/null.
            GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
            GL.BindVertexArray(0);
            GL.UseProgram(0);

            // Delete all the resources.
            GL.DeleteBuffer(VBO);
            GL.DeleteVertexArray(VAO);
            GL.DeleteProgram(shader.Handle);

            shader.Dispose();
        }
    }
}
