﻿using System;

using OpenTK.Graphics.OpenGL4;

namespace OpenTKTesting.Graphics.Shapes
{
    public class Triangle
    {
        private int VAO;
        private int VBO;

        private float[] vertices = {};

        public Triangle(float[] a, float[] b, float[] c)
        {
            float[] vertices =
            {
                a[0], a[1], 0.0f, 1.0f, 0.0f, 0.0f, 1f,    // Bod A
                b[0], b[1], 0.0f, 0.0f, 1.0f, 0.0f, 1f,    // Bod B
                c[0], c[1], 0.0f, 0.0f, 0.0f, 1.0f, 1f,    // Bod C
            };

            this.vertices = vertices;

            // VBO
            VBO = GL.GenBuffer();
            GL.BindBuffer(BufferTarget.ArrayBuffer, VBO);
            GL.BufferData(BufferTarget.ArrayBuffer, vertices.Length * sizeof(float), vertices, BufferUsageHint.StaticDraw);

            // VAO
            VAO = GL.GenVertexArray();
            GL.BindVertexArray(VAO);
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 7 * sizeof(float), 0);
            GL.VertexAttribPointer(1, 4, VertexAttribPointerType.Float, false, 7 * sizeof(float), 3 * sizeof(float));
            GL.EnableVertexAttribArray(0);
            GL.EnableVertexAttribArray(1);
        }

        public void Render()
        {
            // Render part
            GL.BindVertexArray(VAO);
            GL.DrawArrays(PrimitiveType.Triangles, 0, 3);
        }
    }
}
