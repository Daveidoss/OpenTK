﻿using System;
using System.Collections.Generic;

using OpenTK.Graphics.OpenGL4;

namespace OpenTKTesting.Graphics.Shapes
{
    public class Rectangle
    {
        private int VBO;
        private int VAO;
        private int EBO;

        private uint[] indices = { };

        private List<float[]> verticesList = new List<float[]>();

        private float[] v = { 1 };

        public Rectangle(int x, int y, int width, int height, int index)
        {

            GL.BindVertexArray(VAO);

            float[] vertices = {

                x,       y,        0.0f, 1.0f, 0.0f, 0.0f, 1f,    // Bod A
                x+width, y,        0.0f, 0.0f, 1.0f, 0.0f, 1f,    // Bod B
                x+width, y+height, 0.0f, 0.0f, 0.0f, 1.0f, 1f,    // Bod C
                x,       y+height, 0.0f, 1.0f, 1.0f, 0.0f, 1f,    // Bod D
            };

            uint[] indices =
            {
                0, 1, 2,
                0, 2, 3,
            };

            this.indices = indices;

            // VBO
            VBO = GL.GenBuffer();
            GL.BindBuffer(BufferTarget.ArrayBuffer, VBO);
            GL.BufferData(BufferTarget.ArrayBuffer, verticesList[index].Length * sizeof(float), verticesList[index], BufferUsageHint.StaticDraw);

            // VAO
            VAO = GL.GenVertexArray();
            GL.BindVertexArray(VAO);
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 7 * sizeof(float), 0);
            GL.VertexAttribPointer(1, 4, VertexAttribPointerType.Float, false, 7 * sizeof(float), 3 * sizeof(float));
            GL.EnableVertexAttribArray(0);
            GL.EnableVertexAttribArray(1);

            // EBO
            EBO = GL.GenBuffer();
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, EBO);
            GL.BufferData(BufferTarget.ElementArrayBuffer, indices.Length * sizeof(uint), indices, BufferUsageHint.StaticDraw);
        }

        public void Render()
        {
            GL.BindBuffer(BufferTarget.ArrayBuffer, EBO);
            GL.DrawElements(PrimitiveType.Triangles, indices.Length, DrawElementsType.UnsignedInt, 0);
        }
    }
}
