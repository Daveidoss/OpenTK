﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenTKTesting.Graphics
{
    public static class Vertices
    {
        private static List<float[]> verticesList = new List<float[]>();

        public static List<float[]> AddVertices(float[] vertices)
        {
            verticesList.Add(vertices);
            return verticesList;
        }

        public static List<float[]> RemoveVertices(float[] vertices)
        {
            verticesList.Remove(vertices);
            return verticesList;
        }
    }
}
