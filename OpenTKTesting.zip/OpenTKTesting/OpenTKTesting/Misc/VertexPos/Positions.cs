﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenTKTesting.Misc.VertexPos
{
    public class Positions
    {
        public float[] a1 = { 200, 200 };
        public float[] b1 = { 200, 400 };
        public float[] c1 = { 400, 400 };
        
        public float[] a2 = { 150, 20 };
        public float[] b2 = { 300, 800 };
        public float[] c2 = { 400, 505 };
        
        public float[] a3 = { 250, 200 };
        public float[] b3 = { 584, 400 };
        public float[] c3 = { 400, 660 };
    }
}
