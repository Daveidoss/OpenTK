﻿using System;
using System.IO;

using OpenTK.Graphics.OpenGL4;

namespace OpenTKTesting
{
    public class Shader
    {
        public int Handle;

        public Shader(string vertexPath, string fragmentPath)
        {
            string VertSource = File.ReadAllText(vertexPath);
            string FragSource = File.ReadAllText(fragmentPath);

            // Create shaders
            var VertShader = GL.CreateShader(ShaderType.VertexShader);
            GL.ShaderSource(VertShader, VertSource);

            var FragShader = GL.CreateShader(ShaderType.FragmentShader);
            GL.ShaderSource(FragShader, FragSource);

            // Compile
            GL.CompileShader(VertShader);

            GL.GetShader(VertShader, ShaderParameter.CompileStatus, out int success);
            if (success == 0)
            {
                string infoLog = GL.GetShaderInfoLog(VertShader);
                Console.WriteLine(infoLog);
            }

            GL.CompileShader(FragShader);

            GL.GetShader(FragShader, ShaderParameter.CompileStatus, out success);
            if (success == 0)
            {
                string infoLog = GL.GetShaderInfoLog(FragShader);
                Console.WriteLine(infoLog);
            }

            Handle = GL.CreateProgram();

            GL.AttachShader(Handle, VertShader);
            GL.AttachShader(Handle, FragShader);

            GL.LinkProgram(Handle);

            GL.GetProgram(Handle, GetProgramParameterName.LinkStatus, out success);
            if (success == 0)
            {
                string infoLog = GL.GetProgramInfoLog(Handle);
                Console.WriteLine(infoLog);
            }

            GL.DetachShader(Handle, VertShader);
            GL.DetachShader(Handle, FragShader);
            GL.DeleteShader(FragShader);
            GL.DeleteShader(VertShader);

            int[] viewport = new int[4];
            GL.GetInteger((GetPName)GetIndexedPName.Viewport, viewport);
            Use();
            int viewportSizeU = GL.GetUniformLocation(Handle, "ViewportSize");
            GL.Uniform2(viewportSizeU, (float)viewport[2], (float)viewport[3]);
        }

        public void Use()
        {
            GL.UseProgram(Handle);
        }

        private bool disposedValue = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                GL.DeleteProgram(Handle);

                disposedValue = true;
            }
        }

        ~Shader()
        {
            GL.DeleteProgram(Handle);
        }


        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
