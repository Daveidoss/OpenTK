﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenTKTesting.Physics.Movement
{
    public static class Transform
    {
        public static float[] Translate(float x, float y)
        {
            float[] dir = { x, y };

            return dir;
        }
    }
}
